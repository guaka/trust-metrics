
from distutils.core import setup

setup(name='netconv',
      version='0.12',
      author='Marcio Rosa da Silva',
      author_email='mmrsva@gmail.com',
      url='http://pynetconv.sourceforge.net/',
      packages=['netconv'],
      scripts=['netconv-gui.py'],
      )
