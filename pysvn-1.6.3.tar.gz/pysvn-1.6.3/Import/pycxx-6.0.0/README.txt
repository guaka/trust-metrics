PyCXX sources have been forked so that python 2.6 and earlier
can be supported as well as python 3.0 onwards.

PyCXX 6.0 will support Python 3.0 and will be developed on the trunk.

    svn co https://cxx.svn.sourceforge.net/svnroot/cxx/trunk

PyCXX 5.4.x will suppport Python before 3.0 (finally version 2.6.x)
on branch pycxx-5-maint.

    svn co https://cxx.svn.sourceforge.net/svnroot/cxx/branches/pycxx-5-maint

Barry Scott
