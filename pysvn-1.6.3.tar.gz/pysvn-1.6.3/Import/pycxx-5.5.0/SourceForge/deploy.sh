#!/bin/sh
scp index.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/
scp ../README.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/
scp ../Doc/PyCXX.html barry-scott,cxx@web.sourceforge.net:/home/groups/c/cx/cxx/htdocs/
