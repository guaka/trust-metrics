import simple
simple.func()
simple.func( 4, 5 )
simple.func( 4, 5, name=6, value=7 )
cls = simple.cls()
cls.cls_func()
cls.cls_func( 4 )
